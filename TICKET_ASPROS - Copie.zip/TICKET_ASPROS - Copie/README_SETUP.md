# ASPROS - Guide de Démarrage

Plateforme Africaine de Billetterie & Collecte Solidaire

## 📋 Prérequis

- **Node.js** (v18 ou supérieur)
- **PostgreSQL** (v12 ou supérieur)
- **npm** ou **yarn**

## 🗄️ Configuration de la Base de Données

1. **Créer la base de données PostgreSQL :**
```sql
CREATE DATABASE aspros_db;
```

2. **Exécuter le script d'initialisation :**
```bash
cd back_end
psql -U postgres -d aspros_db -f init_db.sql
```

Ou via pgAdmin :
- Ouvrez pgAdmin
- Connectez-vous à votre serveur PostgreSQL
- Cliquez droit sur la base de données `aspros_db`
- Sélectionnez "Query Tool"
- Copiez et collez le contenu de `back_end/init_db.sql`
- Exécutez le script

## 🔧 Configuration du Backend

1. **Naviguer vers le dossier backend :**
```bash
cd back_end
```

2. **Créer le fichier `.env` :**
Copiez le fichier `.env.example` et renommez-le en `.env` :
```bash
cp .env.example .env
```

3. **Configurer les variables d'environnement dans `.env` :**
```env
DB_HOST=localhost
DB_PORT=5432
DB_NAME=aspros_db
DB_USER=postgres
DB_PASSWORD=votre_mot_de_passe_postgres

JWT_SECRET=votre_cle_secrete_jwt_tres_longue_et_securisee
JWT_EXPIRES_IN=7d

PORT=3001
```

4. **Installer les dépendances :**
```bash
npm install
```

5. **Démarrer le serveur backend :**
```bash
node server.js
```

Le backend sera accessible sur `http://localhost:3001`

## 🎨 Configuration du Frontend

1. **Naviguer vers le dossier frontend :**
```bash
cd frontend_ticket/aspros-web
```

2. **Installer les dépendances :**
```bash
npm install
```

3. **Démarrer le serveur de développement :**
```bash
npm run dev
```

Le frontend sera accessible sur `http://localhost:3000`

## 🧪 Tester la Connexion

### Test de l'API Backend

Ouvrez votre navigateur ou utilisez Postman/curl :

- **Test racine :** `http://localhost:3001/`
  - Devrait retourner : `{"message": "API ASPROS Billetterie 🎟️"}`

- **Test événements :** `http://localhost:3001/api/events`
  - Devrait retourner la liste des événements

### Test de l'Authentification

**Inscription :**
```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"nom":"Test User","email":"test@example.com","password":"password123","role":"promoter"}'
```

**Connexion :**
```bash
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

## 📱 Utilisation de l'Application

1. **Accéder à l'application :**
   - Ouvrez `http://localhost:3000` dans votre navigateur

2. **Page d'accueil :**
   - Vous verrez les événements chargés depuis la base de données
   - Les filtres par catégorie fonctionnent

3. **Connexion :**
   - Cliquez sur "Se connecter"
   - Utilisez les identifiants créés lors de l'inscription
   - Après connexion, vous serez redirigé vers le dashboard

## 🐛 Dépannage

### Erreur de connexion à la base de données
- Vérifiez que PostgreSQL est en cours d'exécution
- Vérifiez les identifiants dans le fichier `.env`
- Assurez-vous que la base de données `aspros_db` existe

### Erreur CORS
- Le backend est déjà configuré avec CORS activé
- Vérifiez que le frontend tourne sur le port 3000

### Erreur de dépendances frontend
- Les erreurs TypeScript dans l'IDE sont normales si les dépendances ne sont pas installées
- Exécutez `npm install` dans le dossier frontend

### Le frontend ne charge pas les événements
- Vérifiez que le backend est démarré
- Vérifiez la console du navigateur pour les erreurs
- Assurez-vous que l'URL de l'API est correcte (`http://localhost:3001/api`)

## 📁 Structure du Projet

```
TICKET_ASPROS/
├── back_end/
│   ├── controllers/       # Logique métier
│   ├── routes/           # Routes API
│   ├── db/               # Configuration PostgreSQL
│   ├── middlewares/      # Middlewares (auth, etc.)
│   ├── init_db.sql       # Script d'initialisation DB
│   ├── .env.example      # Exemple de configuration
│   └── server.js         # Point d'entrée
├── frontend_ticket/
│   └── aspros-web/
│       ├── src/
│       │   ├── app/      # Pages Next.js
│       │   ├── components/  # Composants React
│       │   └── lib/      # Utilitaires (API client)
│       └── package.json
└── README_SETUP.md       # Ce fichier
```

## 🚀 Prochaines Étapes

- [ ] Implémenter la création d'événements depuis le dashboard
- [ ] Ajouter le système de paiement (Mobile Money)
- [ ] Implémenter la génération de QR codes
- [ ] Ajouter les notifications email/SMS
- [ ] Déployer en production

## 📞 Support

Pour toute question ou problème, vérifiez d'abord la section Dépannage ci-dessus.
