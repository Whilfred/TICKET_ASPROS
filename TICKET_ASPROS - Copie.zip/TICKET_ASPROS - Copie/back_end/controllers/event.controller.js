const pool = require('../db');

const getAllEvents = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT e.*, ec.name as category_name, 
             COALESCE(SUM(tt.available), 0) as total_tickets,
             COALESCE(SUM(tt.capacity), 0) as total_capacity
      FROM events e
      LEFT JOIN event_categories ec ON e.category_id = ec.id
      LEFT JOIN ticket_types tt ON e.id = tt.event_id
      GROUP BY e.id, ec.name
      ORDER BY e.event_date ASC
    `);
    
    res.json(result.rows);
  } catch (err) {
    console.error('Erreur getAllEvents :', err.message);
    res.status(500).json({ message: 'Erreur serveur' });
  }
};

const getEventById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query(`
      SELECT e.*, ec.name as category_name 
      FROM events e
      LEFT JOIN event_categories ec ON e.category_id = ec.id
      WHERE e.id = $1
    `, [id]);
    
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Événement non trouvé' });
    }
    
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Erreur getEventById :', err.message);
    res.status(500).json({ message: 'Erreur serveur' });
  }
};

const getEventsByCategory = async (req, res) => {
  try {
    const { category } = req.params;
    const result = await pool.query(`
      SELECT e.*, ec.name as category_name 
      FROM events e
      LEFT JOIN event_categories ec ON e.category_id = ec.id
      WHERE ec.name = $1 OR e.id = $1
      ORDER BY e.event_date ASC
    `, [category]);
    
    res.json(result.rows);
  } catch (err) {
    console.error('Erreur getEventsByCategory :', err.message);
    res.status(500).json({ message: 'Erreur serveur' });
  }
};

const createEvent = async (req, res) => {
  try {
    const { title, description, location, event_date, image_url, category_id, promoter_id, status, capacity } = req.body;
    
    const result = await pool.query(
      'INSERT INTO events (title, description, location, event_date, image_url, category_id, promoter_id, status, capacity) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING *',
      [title, description, location, event_date, image_url, category_id, promoter_id, status || 'draft', capacity]
    );
    
    res.status(201).json(result.rows[0]);
  } catch (err) {
    console.error('Erreur createEvent :', err.message);
    res.status(500).json({ message: 'Erreur serveur' });
  }
};

const getSolidarityCampaigns = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT sc.*, 
             (sc.current_amount / sc.goal_amount * 100) as progress_percentage
      FROM solidarity_campaigns sc
      WHERE sc.status = 'active'
      ORDER BY sc.created_at DESC
    `);
    
    res.json(result.rows);
  } catch (err) {
    console.error('Erreur getSolidarityCampaigns :', err.message);
    res.status(500).json({ message: 'Erreur serveur' });
  }
};

module.exports = {
  getAllEvents,
  getEventById,
  getEventsByCategory,
  createEvent,
  getSolidarityCampaigns
};
