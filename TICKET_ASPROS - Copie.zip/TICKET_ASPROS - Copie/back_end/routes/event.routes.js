const express = require('express');
const router = express.Router();
const { getAllEvents, getEventById, getEventsByCategory, createEvent, getSolidarityCampaigns } = require('../controllers/event.controller');

// Routes pour les événements
router.get('/', getAllEvents);
router.get('/:id', getEventById);
router.get('/category/:category', getEventsByCategory);
router.post('/', createEvent);

// Routes pour les campagnes solidaires
router.get('/solidarity/campaigns', getSolidarityCampaigns);

module.exports = router;
