const app = require('./index');
const db = require('./db');

const PORT = process.env.PORT || 3001;

async function startServer() {
  try {
    // Attendre un peu pour s'assurer que la DB est connectée
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Serveur ASPROS backend démarré sur le port ${PORT}`);
    });

  } catch (error) {
    console.error('Erreur lors du démarrage du serveur:', error);
    process.exit(1);
  }
}

startServer();
