-- Script d'initialisation de la base de données ASPROS

-- Création de la base de données (si nécessaire)
-- CREATE DATABASE aspros_db;

-- Extension pour les UUID (si nécessaire)
-- CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    nom VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des portefeuilles (wallets)
CREATE TABLE IF NOT EXISTS wallets (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    balance DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des catégories d'événements
CREATE TABLE IF NOT EXISTS event_categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des événements
CREATE TABLE IF NOT EXISTS events (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255),
    event_date TIMESTAMP,
    image_url TEXT,
    category_id INTEGER REFERENCES event_categories(id),
    promoter_id INTEGER REFERENCES users(id),
    status VARCHAR(50) DEFAULT 'draft',
    capacity INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des types de billets
CREATE TABLE IF NOT EXISTS ticket_types (
    id SERIAL PRIMARY KEY,
    event_id INTEGER REFERENCES events(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    capacity INTEGER,
    available INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des commandes
CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id),
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    payment_method VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des billets
CREATE TABLE IF NOT EXISTS tickets (
    id SERIAL PRIMARY KEY,
    order_id INTEGER REFERENCES orders(id),
    ticket_type_id INTEGER REFERENCES ticket_types(id),
    event_id INTEGER REFERENCES events(id),
    qr_code VARCHAR(255) UNIQUE,
    status VARCHAR(50) DEFAULT 'valid',
    scanned BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des campagnes solidaires
CREATE TABLE IF NOT EXISTS solidarity_campaigns (
    id SERIAL PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    goal_amount DECIMAL(10, 2) NOT NULL,
    current_amount DECIMAL(10, 2) DEFAULT 0,
    organizer_id INTEGER REFERENCES users(id),
    image_url TEXT,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des donations
CREATE TABLE IF NOT EXISTS donations (
    id SERIAL PRIMARY KEY,
    campaign_id INTEGER REFERENCES solidarity_campaigns(id),
    user_id INTEGER REFERENCES users(id),
    amount DECIMAL(10, 2) NOT NULL,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertion des données de test pour les catégories
INSERT INTO event_categories (name, description) VALUES
('Concerts', 'Événements musicaux et concerts'),
('Cinéma', 'Séances de cinéma et projections'),
('Solidarité', 'Campagnes de collecte et causes sociales'),
('Formation', 'Sessions de formation et ateliers')
ON CONFLICT DO NOTHING;

-- Insertion des données de test pour les événements
INSERT INTO events (title, description, location, event_date, image_url, category_id, promoter_id, status, capacity) VALUES
('Afrobeat 2026', 'Le plus grand festival de musique afrobeat de la région', 'Palais des Congrès', '2026-07-15 19:00:00', 'https://images.unsplash.com/photo-1540039155733-5bb30b53aa14?w=800', 1, 1, 'published', 1000),
('Black Panther 3', 'Avant-première exclusive du nouveau Marvel', 'Cinéma Gaumont', '2026-08-20 20:00:00', 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=800', 2, 1, 'published', 500),
('Gala de Charité pour les Orphelins', 'Soirée de gala au profit des orphelins', 'Hôtel Hilton', '2026-09-10 18:30:00', 'https://images.unsplash.com/photo-1511632765486-a01980e01a18?w=800', 3, 1, 'published', 200),
('Masterclass Tech', 'Formation intensive sur les nouvelles technologies', 'Tech Hub', '2026-10-05 09:00:00', 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?w=800', 4, 1, 'draft', 50)
ON CONFLICT DO NOTHING;

-- Insertion des données de test pour les types de billets
INSERT INTO ticket_types (event_id, name, price, capacity, available) VALUES
(1, 'Standard', 5000, 800, 800),
(1, 'VIP', 15000, 200, 200),
(2, 'Standard', 3000, 400, 400),
(2, 'VIP', 8000, 100, 100),
(3, 'Don Libre', 0, 200, 200),
(4, 'Standard', 25000, 50, 50)
ON CONFLICT DO NOTHING;

-- Insertion des données de test pour les campagnes solidaires
INSERT INTO solidarity_campaigns (title, description, goal_amount, current_amount, organizer_id, image_url, status) VALUES
('Aide aux Étudiants Défavorisés', 'Soutien aux étudiants sans moyens pour poursuivre leurs études', 5000000, 1250000, 1, 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6?w=800', 'active'),
('Soins Médicaux pour Enfants', 'Financement des soins médicaux pour les enfants défavorisés', 10000000, 3500000, 1, 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800', 'active')
ON CONFLICT DO NOTHING;
