const API_BASE_URL = 'http://localhost:3001/api';

interface LoginCredentials {
  email: string;
  password: string;
}

interface RegisterCredentials {
  nom: string;
  email: string;
  password: string;
  role?: string;
}

interface AuthResponse {
  message: string;
  token: string;
  user: {
    id: number;
    nom: string;
    email: string;
    role: string;
  };
}

interface Event {
  id: number;
  title: string;
  description: string;
  location: string;
  event_date: string;
  image_url: string;
  category_name: string;
  status: string;
  capacity: number;
  total_tickets?: number;
  total_capacity?: number;
}

interface SolidarityCampaign {
  id: number;
  title: string;
  description: string;
  goal_amount: number;
  current_amount: number;
  progress_percentage: number;
  image_url: string;
  status: string;
}

class ApiClient {
  private async request<T>(endpoint: string, options?: RequestInit): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options?.headers as Record<string, string> || {}),
    };

    const token = typeof window !== 'undefined' ? localStorage.getItem('token') : null;
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    try {
      const response = await fetch(url, {
        ...options,
        headers,
      });

      if (!response.ok) {
        const error = await response.json().catch(() => ({ message: 'Erreur réseau' }));
        throw new Error(error.message || 'Erreur lors de la requête');
      }

      return await response.json();
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Authentification
  async login(credentials: LoginCredentials): Promise<AuthResponse> {
    return this.request<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async register(credentials: RegisterCredentials): Promise<AuthResponse> {
    return this.request<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  // Événements
  async getAllEvents(): Promise<Event[]> {
    return this.request<Event[]>('/events');
  }

  async getEventById(id: number): Promise<Event> {
    return this.request<Event>(`/events/${id}`);
  }

  async getEventsByCategory(category: string): Promise<Event[]> {
    return this.request<Event[]>(`/events/category/${category}`);
  }

  async createEvent(eventData: Partial<Event>): Promise<Event> {
    return this.request<Event>('/events', {
      method: 'POST',
      body: JSON.stringify(eventData),
    });
  }

  // Campagnes solidaires
  async getSolidarityCampaigns(): Promise<SolidarityCampaign[]> {
    return this.request<SolidarityCampaign[]>('/events/solidarity/campaigns');
  }
}

export const apiClient = new ApiClient();
export type { Event, SolidarityCampaign, LoginCredentials, RegisterCredentials, AuthResponse };
