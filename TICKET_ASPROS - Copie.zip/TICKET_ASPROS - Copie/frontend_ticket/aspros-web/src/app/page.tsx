"use client";

import { useState, useEffect } from 'react';
import { EventCard, EventData } from '@/components/EventCard';
import styles from './page.module.css';
import { apiClient, Event as ApiEvent } from '@/lib/api';

export default function Home() {
  const [events, setEvents] = useState<EventData[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState('Tous');

  useEffect(() => {
    loadEvents();
  }, [selectedCategory]);

  const loadEvents = async () => {
    try {
      setLoading(true);
      let data: ApiEvent[];
      
      if (selectedCategory === 'Tous') {
        data = await apiClient.getAllEvents();
      } else {
        data = await apiClient.getEventsByCategory(selectedCategory);
      }

      // Transformer les données de l'API en format EventData
      const transformedEvents: EventData[] = data
        .filter(event => event.status === 'published')
        .map(event => {
          // Mapper la catégorie vers un type valide
          let category: 'Concert' | 'Cinéma' | 'Solidarité' | 'Sport' = 'Concert';
          const catName = event.category_name?.toLowerCase() || '';
          if (catName.includes('cinéma')) category = 'Cinéma';
          else if (catName.includes('solidarité')) category = 'Solidarité';
          else if (catName.includes('sport')) category = 'Sport';

          return {
            id: event.id.toString(),
            title: event.title,
            date: new Date(event.event_date).toLocaleDateString('fr-FR', { 
              day: 'numeric', 
              month: 'long', 
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit'
            }),
            location: event.location,
            category,
            imageUrl: event.image_url || '',
            price: category === 'Solidarité' ? 'Don Libre' : '5 000 FCFA'
          };
        });

      setEvents(transformedEvents);
    } catch (error) {
      console.error('Erreur lors du chargement des événements:', error);
      // En cas d'erreur, utiliser des données mockées
      setEvents([
        {
          id: '1',
          title: 'Festival Afrobeat 2026',
          date: '15 Juillet 2026 • 18:00',
          location: 'Stade de l\'Amitié',
          category: 'Concert',
          imageUrl: '',
          price: '15 000 FCFA'
        },
        {
          id: '2',
          title: 'Avant-première : Black Panther 3',
          date: '20 Août 2026 • 20:30',
          location: 'Canal Olympia',
          category: 'Cinéma',
          imageUrl: '',
          price: '5 000 FCFA'
        },
        {
          id: '3',
          title: 'Gala de Charité - Enfants Orphelins',
          date: '05 Septembre 2026 • 19:00',
          location: 'Hôtel Azalaï',
          category: 'Solidarité',
          imageUrl: '',
          price: 'Don Libre'
        }
      ]);
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className={styles.container}>
      {/* Hero Section */}
      <section className={styles.hero}>
        <div className={styles.heroContent}>
          <h1 className={styles.heroTitle}>
            Vivez l'Événement, <br />
            <span className={styles.highlight}>Autrement.</span>
          </h1>
          <p className={styles.heroSubtitle}>
            Découvrez les meilleurs concerts, films, et participez à des collectes solidaires 
            partout en Afrique. La billetterie de nouvelle génération est là.
          </p>
          <div className={styles.heroActions}>
            <button className="btn-primary" style={{ padding: '16px 32px', fontSize: '1.1rem' }}>
              Découvrir les événements
            </button>
          </div>
        </div>
        <div className={styles.heroDecorations}>
          {/* Abstract background shapes */}
          <div className={`${styles.blob} ${styles.blob1}`}></div>
          <div className={`${styles.blob} ${styles.blob2}`}></div>
        </div>
      </section>

      {/* Events Section */}
      <section className={styles.eventsSection}>
        <div className={styles.sectionHeader}>
          <h2 className={styles.sectionTitle}>À la une</h2>
          <div className={styles.filters}>
            <button className={`${styles.filterBtn} ${styles.active}`}>Tous</button>
            <button className={styles.filterBtn}>Concerts</button>
            <button className={styles.filterBtn}>Cinéma</button>
            <button className={styles.filterBtn}>Solidarité</button>
          </div>
        </div>

        <div className={styles.eventsGrid}>
          {loading ? (
            <div style={{ textAlign: 'center', padding: '40px' }}>Chargement...</div>
          ) : events.length === 0 ? (
            <div style={{ textAlign: 'center', padding: '40px' }}>Aucun événement disponible</div>
          ) : (
            events.map((event: EventData) => (
              <EventCard key={event.id} event={event} />
            ))
          )}
        </div>
      </section>
    </div>
  );
}
